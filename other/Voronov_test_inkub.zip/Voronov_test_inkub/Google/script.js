
const myArray = [
    {name: 'John', age: 18},
    {name: 'Alex', age: 55},
    {name: 'Dimy4', age: 7},
    {name: 'Honza', age: 72}
];

const searchBtn = document.querySelector('.search-button');
const searchInput = document.querySelector('.search-input');

searchBtn.addEventListener('click', () => {
    if ( searchInput.value === 'google' || searchInput.value === 'GOOGLE' || searchInput.value === 'Google' ) {
        alert('Yandex круче. Но это не точно')
    } else {
        alert(searchInput.value);
    }
    alert(myArray[0].name);
})
