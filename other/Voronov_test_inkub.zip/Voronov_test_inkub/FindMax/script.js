
const findBtn = document.querySelector('.find-btn');
let p1 = document.querySelector('.p1');
let p2 = document.querySelector('.p2');

let myArr = [45, 87, 21, 69, 17, 25, 67, 21];
p1.innerHTML = (`Incoming array: ${myArr}`);

const findMax = arr => {
    p2.innerHTML=(`Max of incoming array is: ${(arr.sort( (a, b) => b-a ))[0]}`);
}

findBtn.addEventListener('click', () => {
    findMax(myArr);
});