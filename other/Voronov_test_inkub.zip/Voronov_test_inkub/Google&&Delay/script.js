const searchBtn = document.querySelector('.search-button');
const searchInput = document.querySelector('.search-input');


let msg = string => {
    setTimeout(() => alert(string), 3000);
}

searchBtn.addEventListener('click', () => {
    searchInput.value === 'google' ? msg('Yandex круче. Но это не точно') : msg(searchInput.value);
})
