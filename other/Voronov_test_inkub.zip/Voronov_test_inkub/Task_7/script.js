
const btn = document.querySelector('.btn');
const p = document.querySelector(".p");

let myArr = [25, 88, 1, 98, 71, 36];
p.innerHTML = myArr;

let sorted = myArr.sort( (a, b) => b - a );

const maxItem = sorted[0];
const minItem = sorted[sorted.length-1];

btn.addEventListener('click', () => {
    alert(`max: ${maxItem}; min: ${minItem}`);
});