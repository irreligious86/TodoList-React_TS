
const btn = document.querySelector('.btn');

let p1 = document.getElementById('p1');

let a = 21;
let b = 75;

p1.innerHTML=(`a: ${a}, b: ${b}`);

btn.addEventListener('click', () => {
    a = a+b;
    b = b-a;
    b = -b;
    a = a-b;
    p1.innerHTML=(`a: ${a}, b: ${b}`);
});