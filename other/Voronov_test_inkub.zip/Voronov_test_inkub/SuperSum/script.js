
const startBtn = document.querySelector('.start-super-sum');

const superSum = (a, b) => a+b;

startBtn.addEventListener('click', () => {
    let a = +prompt("type first operand", '0');
    let b = +prompt("second first operand", '0');
    alert('superSum(a, b): ' + superSum(a, b));
})

